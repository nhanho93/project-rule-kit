[CmdletBinding()]
param(
    [ValidateSet("All", "Codex", "Antigravity")]
    [string]$Agent = "All",
    [string]$InstallRoot = (Join-Path $env:USERPROFILE ".browser-mcp-x-qc"),
    [switch]$RemoveFiles
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Write-Utf8NoBom([string]$Path, [string]$Content) {
    [System.IO.File]::WriteAllText($Path, $Content, $Utf8NoBom)
}

function Remove-JsonServers([string]$Path, [string]$ContainerName) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $json = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    $property = $json.PSObject.Properties[$ContainerName]
    if (-not $property) { return }
    $container = $property.Value
    $container.PSObject.Properties.Remove("browser_qc_current")
    $container.PSObject.Properties.Remove("browser_qc_dedicated")
    Write-Utf8NoBom $Path ($json | ConvertTo-Json -Depth 12)
    Write-Host "[OK] Updated: $Path"
}

if ($Agent -in @("All", "Codex")) {
    $configPath = Join-Path $env:USERPROFILE ".codex\config.toml"
    if (Test-Path -LiteralPath $configPath) {
        $config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8
        foreach ($name in @("browser_qc_current", "browser_qc_current.env", "browser_qc_dedicated", "browser_qc_dedicated.env")) {
            $escaped = [regex]::Escape($name)
            $config = [regex]::Replace($config, "(?ms)^\[mcp_servers\.$escaped\]\s*.*?(?=^\[|\z)", "")
        }
        Write-Utf8NoBom $configPath ($config.TrimEnd() + "`r`n")
        Write-Host "[OK] Updated: $configPath"
    }
}

if ($Agent -in @("All", "Antigravity")) {
    Remove-JsonServers (Join-Path $env:USERPROFILE ".gemini\config\mcp_config.json") "mcpServers"
    Remove-JsonServers (Join-Path $env:APPDATA "Antigravity\User\mcp.json") "servers"
    Remove-JsonServers (Join-Path $env:APPDATA "Antigravity IDE\User\mcp.json") "servers"
}

if ($RemoveFiles -and (Test-Path -LiteralPath $InstallRoot)) {
    $resolved = [System.IO.Path]::GetFullPath($InstallRoot)
    $profileRoot = [System.IO.Path]::GetFullPath($env:USERPROFILE).TrimEnd('\') + '\'
    if (-not $resolved.StartsWith($profileRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to remove a directory outside the user profile: $resolved"
    }
    Remove-Item -LiteralPath $resolved -Recurse -Force
    Write-Host "[OK] Removed: $resolved"
}

Write-Host "[INFO] Restart the affected agent to unload the removed MCP servers."

# Agent instructions

Use this MCP for browser QC when native browser control is unavailable or lacks the required diagnostics.

## Routing rule

- Explicit request for the user's existing Chrome tabs, login, or extensions: use `browser_qc_current`.
- Isolated, repeatable, destructive, or unspecified session: use `browser_qc_dedicated`.
- Do not switch sessions without telling the user.
- Start every run with `qc_session_info` and verify the returned `instance`.

## E2E rule

1. Establish the expected user flow and acceptance criteria.
2. Inspect the visible page state before each interaction.
3. Record console and network evidence when a step fails.
4. Use `qc_e2e_checkpoint` after meaningful state transitions.
5. Report exact reproduction steps, expected behavior, actual behavior, severity, and evidence.

## Visual rule

1. Use `qc_visual_matrix` for mobile, tablet, and desktop.
2. Review overflow, clipping, overlap, spacing, typography, contrast, loading states, responsive layout, and interactive states.
3. Compare screenshots only after the page has reached a stable state.
4. Do not approve visual QA from a single viewport.

## Deep-debug rule

All debug tools are intentionally available. Cookie, token, API-session, request-body, cURL, and JavaScript tools may be used when necessary for the requested debugging scope. Do not export or reuse unrelated authenticated data.

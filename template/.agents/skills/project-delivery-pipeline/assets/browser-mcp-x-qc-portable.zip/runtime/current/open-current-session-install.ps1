$ErrorActionPreference = "Stop"

$chromePath = "C:\Program Files\Google\Chrome\Application\chrome.exe"
$extensionDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path -LiteralPath $chromePath)) {
    throw "Google Chrome was not found at $chromePath"
}

Set-Clipboard -Value $extensionDir
Start-Process -FilePath $chromePath -ArgumentList "chrome://extensions"

Write-Host "Extension folder copied to clipboard: $extensionDir"
Write-Host "Enable Developer mode, choose Load unpacked, then paste the folder path."

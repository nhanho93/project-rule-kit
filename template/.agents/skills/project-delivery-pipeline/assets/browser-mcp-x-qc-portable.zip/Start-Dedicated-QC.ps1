$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$launcher = Join-Path $root "runtime\dedicated\launch-dedicated-chrome.ps1"
if (-not (Test-Path -LiteralPath $launcher)) {
    throw "Dedicated launcher not found: $launcher"
}
& $launcher

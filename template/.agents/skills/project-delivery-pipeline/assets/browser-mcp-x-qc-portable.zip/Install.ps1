[CmdletBinding()]
param(
    [ValidateSet("All", "Codex", "Antigravity", "FilesOnly")]
    [string]$Agent = "All",
    [string]$InstallRoot = (Join-Path $env:USERPROFILE ".browser-mcp-x-qc")
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$BundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RuntimeSource = Join-Path $BundleRoot "runtime"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Write-Utf8NoBom([string]$Path, [string]$Content) {
    $parent = Split-Path -Parent $Path
    if ($parent) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    [System.IO.File]::WriteAllText($Path, $Content, $Utf8NoBom)
}

function Backup-Config([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss-fff"
    Copy-Item -LiteralPath $Path -Destination "$Path.browser-mcp-x-qc.$stamp.bak" -Force
}

function Set-JsonProperty($Object, [string]$Name, $Value) {
    if ($Object.PSObject.Properties[$Name]) { $Object.$Name = $Value }
    else { $Object | Add-Member -MemberType NoteProperty -Name $Name -Value $Value }
}

function Read-JsonObject([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return [pscustomobject]@{} }
    $raw = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($raw)) { return [pscustomobject]@{} }
    return $raw | ConvertFrom-Json
}

function New-ServerEntry([string]$RelayPath, [string]$Instance, [string]$WsPort, [string]$McpPort) {
    return [pscustomobject][ordered]@{
        command = $script:PythonCommand
        args = @($RelayPath)
        env = [pscustomobject][ordered]@{
            BROWSER_MCP_X_INSTANCE = $Instance
            BROWSER_MCP_X_WS_PORT = $WsPort
            BROWSER_MCP_X_MCP_PORT = $McpPort
        }
    }
}

function Get-ServerEntries([string]$CurrentRelay, [string]$DedicatedRelay) {
    return [ordered]@{
        browser_qc_current = New-ServerEntry $CurrentRelay "current" "9274" "9275"
        browser_qc_dedicated = New-ServerEntry $DedicatedRelay "dedicated" "9374" "9375"
    }
}

function Install-CodexConfig([string]$CurrentRelay, [string]$DedicatedRelay) {
    $configPath = Join-Path $env:USERPROFILE ".codex\config.toml"
    $config = if (Test-Path -LiteralPath $configPath) {
        Get-Content -LiteralPath $configPath -Raw -Encoding UTF8
    } else { "" }
    Backup-Config $configPath
    foreach ($name in @("browser_qc_current", "browser_qc_current.env", "browser_qc_dedicated", "browser_qc_dedicated.env")) {
        $escaped = [regex]::Escape($name)
        $config = [regex]::Replace($config, "(?ms)^\[mcp_servers\.$escaped\]\s*.*?(?=^\[|\z)", "")
    }
    $currentToml = $CurrentRelay.Replace("'", "''")
    $dedicatedToml = $DedicatedRelay.Replace("'", "''")
    $pythonToml = $script:PythonCommand.Replace("'", "''")
    $block = @"

[mcp_servers.browser_qc_current]
command = '$pythonToml'
args = ['$currentToml']
startup_timeout_sec = 120

[mcp_servers.browser_qc_current.env]
BROWSER_MCP_X_INSTANCE = "current"
BROWSER_MCP_X_WS_PORT = "9274"
BROWSER_MCP_X_MCP_PORT = "9275"

[mcp_servers.browser_qc_dedicated]
command = '$pythonToml'
args = ['$dedicatedToml']
startup_timeout_sec = 120

[mcp_servers.browser_qc_dedicated.env]
BROWSER_MCP_X_INSTANCE = "dedicated"
BROWSER_MCP_X_WS_PORT = "9374"
BROWSER_MCP_X_MCP_PORT = "9375"
"@
    Write-Utf8NoBom $configPath ($config.TrimEnd() + "`r`n" + $block.TrimStart())
    Write-Host "[OK] Configured Codex: $configPath"
}

function Install-JsonConfig([string]$Path, [string]$ContainerName, $Entries, [switch]$UseStdioType) {
    Backup-Config $Path
    $json = Read-JsonObject $Path
    if (-not $json.PSObject.Properties[$ContainerName]) {
        Set-JsonProperty $json $ContainerName ([pscustomobject]@{})
    }
    $container = $json.PSObject.Properties[$ContainerName].Value
    foreach ($name in $Entries.Keys) {
        $entry = $Entries[$name] | Select-Object command, args, env
        if ($UseStdioType) { Set-JsonProperty $entry "type" "stdio" }
        Set-JsonProperty $container $name $entry
    }
    if (($ContainerName -eq "servers") -and (-not $json.PSObject.Properties["inputs"])) {
        Set-JsonProperty $json "inputs" @()
    }
    Write-Utf8NoBom $Path ($json | ConvertTo-Json -Depth 12)
    Write-Host "[OK] Configured Antigravity: $Path"
}

function Install-AntigravityConfig([string]$CurrentRelay, [string]$DedicatedRelay) {
    $entries = Get-ServerEntries $CurrentRelay $DedicatedRelay
    $cliConfig = Join-Path $env:USERPROFILE ".gemini\config\mcp_config.json"
    Install-JsonConfig $cliConfig "mcpServers" $entries

    foreach ($ideConfig in @(
        (Join-Path $env:APPDATA "Antigravity\User\mcp.json"),
        (Join-Path $env:APPDATA "Antigravity IDE\User\mcp.json")
    )) {
        $parent = Split-Path -Parent $ideConfig
        if ((Test-Path -LiteralPath $parent) -or (Test-Path -LiteralPath $ideConfig)) {
            Install-JsonConfig $ideConfig "servers" $entries -UseStdioType
        }
    }
}

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { throw "Python 3 was not found in PATH." }
$script:PythonCommand = $python.Source
if (-not (Test-Path -LiteralPath $RuntimeSource)) { throw "Bundle runtime folder is missing: $RuntimeSource" }

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
foreach ($directory in @("runtime", "tests")) {
    Copy-Item -LiteralPath (Join-Path $BundleRoot $directory) -Destination $InstallRoot -Recurse -Force
}
foreach ($file in @("Install.ps1", "Uninstall.ps1", "Start-Dedicated-QC.ps1", "Open-Current-Extension-Setup.ps1", "Self-Test.ps1", "README.md", "AGENT-INSTRUCTIONS.md", "PORTABLE-MANIFEST.json", "VERSION")) {
    Copy-Item -LiteralPath (Join-Path $BundleRoot $file) -Destination $InstallRoot -Force
}

$currentRelay = Join-Path $InstallRoot "runtime\current\relay.py"
$dedicatedRelay = Join-Path $InstallRoot "runtime\dedicated\relay.py"
if ($Agent -in @("All", "Codex")) { Install-CodexConfig $currentRelay $dedicatedRelay }
if ($Agent -in @("All", "Antigravity")) { Install-AntigravityConfig $currentRelay $dedicatedRelay }

Write-Host "[OK] Browser MCP X QC installed at: $InstallRoot"
Write-Host "[INFO] Restart the selected agent so it reloads MCP configuration."

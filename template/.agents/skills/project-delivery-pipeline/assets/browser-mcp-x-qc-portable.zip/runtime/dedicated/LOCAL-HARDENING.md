# Browser MCP X - Local Hardened Install

Source ZIP SHA256:

`502B368F3A1AAC05378C62292E5FF6DE82DEB21D50F42F313D6354CD83338462`

Local changes:

1. HTTP MCP/status server binds to `127.0.0.1` instead of `0.0.0.0`.
2. HTTP requests containing an `Origin` header are rejected.
3. WebSocket handshakes are accepted only from `chrome-extension://` origins.
4. The extension is launched in a dedicated Chrome profile with sync disabled.

Security boundary:

- This extension can navigate, click, type, evaluate JavaScript, inspect network traffic, and export cookies/auth headers when those tools are called.
- Do not use the dedicated profile for personal email, banking, production admin, or unrelated authenticated accounts.
- Log in only to websites intentionally placed in scope for browser R&D.
- Close the dedicated Chrome window when browser automation is not needed.

Launch the isolated browser profile:

```powershell
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.codex\mcp\browser-mcp-x\launch-dedicated-chrome.ps1"
```

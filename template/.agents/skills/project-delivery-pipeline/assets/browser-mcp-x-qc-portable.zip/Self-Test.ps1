[CmdletBinding()]
param([string]$BundleRoot)

$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($BundleRoot)) {
    $BundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
}
$testScript = Join-Path $BundleRoot "tests\smoke_test.py"
if (-not (Test-Path -LiteralPath $testScript)) {
    throw "Smoke test not found: $testScript"
}
python $testScript $BundleRoot
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$installerTest = Join-Path $BundleRoot "tests\installer_test.ps1"
if (-not (Test-Path -LiteralPath $installerTest)) {
    throw "Installer test not found: $installerTest"
}
& $installerTest

Write-Host "Portable bundle self-test passed."

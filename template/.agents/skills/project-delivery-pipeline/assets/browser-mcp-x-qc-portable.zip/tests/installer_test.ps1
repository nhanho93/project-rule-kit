$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$BundleRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$TempBase = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath()).TrimEnd('\') + '\'
$TestRoot = Join-Path $TempBase ("browser-mcp-x-qc-test-" + [guid]::NewGuid().ToString("N"))
$OriginalProfile = $env:USERPROFILE
$OriginalAppData = $env:APPDATA

function Assert-ServerNames([string]$Path, [string[]]$Expected) {
    $json = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    $actual = @($json.mcpServers.PSObject.Properties.Name)
    foreach ($name in $Expected) {
        if ($name -notin $actual) { throw "Missing MCP server '$name' in $Path" }
    }
    if ($actual.Count -ne $Expected.Count) {
        throw "Unexpected MCP servers in ${Path}: $($actual -join ', ')"
    }
}

try {
    $FakeProfile = Join-Path $TestRoot "profile"
    $FakeAppData = Join-Path $TestRoot "appdata"
    $GeminiConfig = Join-Path $FakeProfile ".gemini\config\mcp_config.json"
    $CodexConfig = Join-Path $FakeProfile ".codex\config.toml"
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $GeminiConfig) | Out-Null
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $CodexConfig) | Out-Null
    New-Item -ItemType Directory -Force -Path $FakeAppData | Out-Null
    Copy-Item -LiteralPath (Join-Path $BundleRoot "tests\fixtures\antigravity-agent.json") -Destination $GeminiConfig
    Copy-Item -LiteralPath (Join-Path $BundleRoot "tests\fixtures\codex-config.toml") -Destination $CodexConfig

    $env:USERPROFILE = $FakeProfile
    $env:APPDATA = $FakeAppData
    $InstallRoot = Join-Path $FakeProfile ".browser-mcp-x-qc"
    & (Join-Path $BundleRoot "Install.ps1") -Agent All -InstallRoot $InstallRoot

    Assert-ServerNames $GeminiConfig @("existing_server", "browser_qc_current", "browser_qc_dedicated")
    $codexText = Get-Content -LiteralPath $CodexConfig -Raw -Encoding UTF8
    foreach ($name in @("existing_server", "browser_qc_current", "browser_qc_dedicated")) {
        if ($codexText -notmatch [regex]::Escape($name)) { throw "Missing Codex server '$name'" }
    }
    foreach ($name in @("Install.ps1", "Uninstall.ps1")) {
        if (-not (Test-Path -LiteralPath (Join-Path $InstallRoot $name))) {
            throw "Installed package omitted $name"
        }
    }

    & (Join-Path $BundleRoot "Uninstall.ps1") -Agent All -InstallRoot $InstallRoot
    Assert-ServerNames $GeminiConfig @("existing_server")
    $codexText = Get-Content -LiteralPath $CodexConfig -Raw -Encoding UTF8
    if (($codexText -notmatch "existing_server") -or ($codexText -match "browser_qc_")) {
        throw "Codex uninstall did not preserve only the existing server"
    }
    Write-Host "Installer preservation test passed."
}
finally {
    $env:USERPROFILE = $OriginalProfile
    $env:APPDATA = $OriginalAppData
    $resolved = [System.IO.Path]::GetFullPath($TestRoot)
    if ($resolved.StartsWith($TempBase, [System.StringComparison]::OrdinalIgnoreCase) -and
        (Split-Path -Leaf $resolved).StartsWith("browser-mcp-x-qc-test-")) {
        Remove-Item -LiteralPath $resolved -Recurse -Force -ErrorAction SilentlyContinue
    }
}

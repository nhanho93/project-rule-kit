$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$extensionDir = Join-Path $root "runtime\current"
$chromePath = "C:\Program Files\Google\Chrome\Application\chrome.exe"

if (-not (Test-Path -LiteralPath $chromePath)) {
    throw "Google Chrome was not found at $chromePath"
}
if (-not (Test-Path -LiteralPath (Join-Path $extensionDir "manifest.json"))) {
    throw "Current-session extension is missing: $extensionDir"
}

Set-Clipboard -Value $extensionDir
Start-Process -FilePath $chromePath -ArgumentList "chrome://extensions"
Write-Host "Extension folder copied to clipboard: $extensionDir"
Write-Host "Enable Developer mode, choose Load unpacked, then paste the copied path."

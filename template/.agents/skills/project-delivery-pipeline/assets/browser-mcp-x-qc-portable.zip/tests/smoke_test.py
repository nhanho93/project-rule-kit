import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path


def find_free_port() -> str:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return str(probe.getsockname()[1])


def run_case(name: str, relay: Path, ws_port: str, mcp_port: str) -> None:
    env = os.environ.copy()
    env.update(
        {
            "BROWSER_MCP_X_INSTANCE": name,
            "BROWSER_MCP_X_WS_PORT": ws_port,
            "BROWSER_MCP_X_MCP_PORT": mcp_port,
        }
    )
    process = subprocess.Popen(
        [sys.executable, str(relay)],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
        bufsize=1,
        env=env,
    )
    try:
        requests = [
            {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}},
            {
                "jsonrpc": "2.0",
                "id": 3,
                "method": "tools/call",
                "params": {"name": "qc_session_info", "arguments": {}},
            },
        ]
        for request in requests:
            process.stdin.write(json.dumps(request) + "\n")
        process.stdin.flush()

        responses = []
        deadline = time.time() + 12
        while len(responses) < len(requests) and time.time() < deadline:
            line = process.stdout.readline()
            if line:
                responses.append(json.loads(line))

        if len(responses) != len(requests):
            raise RuntimeError(f"{name}: expected 3 responses, got {len(responses)}")

        server_name = responses[0]["result"]["serverInfo"]["name"]
        if not server_name.endswith(name):
            raise RuntimeError(f"{name}: wrong server identity {server_name}")

        for response in responses:
            if "error" in response:
                raise RuntimeError(f"{name}: MCP error response {response['error']}")

        tool_names = {tool["name"] for tool in responses[1]["result"]["tools"]}
        required = {
            "qc_e2e_checkpoint",
            "qc_visual_matrix",
            "qc_session_info",
            "export_api_session",
            "get_api_requests",
            "get_curl_command",
        }
        missing = required - tool_names
        if missing:
            raise RuntimeError(f"{name}: missing tools {sorted(missing)}")

        session = json.loads(responses[2]["result"]["content"][0]["text"])
        if session["instance"] != name or session["debug_tools"] != "unrestricted":
            raise RuntimeError(f"{name}: invalid session info {session}")

        print(f"{name}: OK ({len(tool_names)} tools)")
    finally:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()


def main() -> None:
    root = Path(sys.argv[1]).resolve()
    required_files = {
        "Install.ps1",
        "Uninstall.ps1",
        "README.md",
        "PORTABLE-MANIFEST.json",
        "Start-Dedicated-QC.ps1",
        "Open-Current-Extension-Setup.ps1",
    }
    missing_package_files = sorted(
        name for name in required_files if not (root / name).is_file()
    )
    if missing_package_files:
        raise FileNotFoundError(
            f"Portable package is incomplete: {missing_package_files}"
        )

    cases = [
        ("current", root / "runtime" / "current" / "relay.py", find_free_port(), find_free_port()),
        ("dedicated", root / "runtime" / "dedicated" / "relay.py", find_free_port(), find_free_port()),
    ]
    for name, relay, ws_port, mcp_port in cases:
        if not relay.is_file():
            raise FileNotFoundError(relay)
        run_case(name, relay, ws_port, mcp_port)


if __name__ == "__main__":
    main()

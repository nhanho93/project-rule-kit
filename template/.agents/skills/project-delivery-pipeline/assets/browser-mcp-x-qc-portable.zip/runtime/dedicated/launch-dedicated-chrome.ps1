$ErrorActionPreference = "Stop"

$extensionDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$profileDir = Join-Path $env:LOCALAPPDATA "BrowserMCPX\ChromeProfile"
$playwrightRoot = Join-Path $env:LOCALAPPDATA "ms-playwright"
$chromium = Get-ChildItem -LiteralPath $playwrightRoot -Recurse -Filter chrome.exe -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match 'chromium-[^\\]+\\chrome-win(64)?\\chrome\.exe$' } |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1
$chromePath = if ($chromium) {
    $chromium.FullName
} else {
    "C:\Program Files\Google\Chrome\Application\chrome.exe"
}

if (-not (Test-Path -LiteralPath $chromePath)) {
    throw "Google Chrome was not found at $chromePath"
}

New-Item -ItemType Directory -Force -Path $profileDir | Out-Null

$chromeArgs = @(
    "--user-data-dir=$profileDir"
    "--load-extension=$extensionDir"
    "--disable-extensions-except=$extensionDir"
    "--disable-sync"
    "--no-first-run"
    "--no-default-browser-check"
    "about:blank"
)

Start-Process -FilePath $chromePath -ArgumentList $chromeArgs

Write-Host "Dedicated QC browser: $chromePath"
Write-Host "Profile: $profileDir"

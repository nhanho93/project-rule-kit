# Browser MCP X - Local Hardened Install

Source ZIP SHA256:

`502B368F3A1AAC05378C62292E5FF6DE82DEB21D50F42F313D6354CD83338462`

Local changes:

1. HTTP MCP/status server binds to `127.0.0.1` instead of `0.0.0.0`.
2. HTTP requests containing an `Origin` header are rejected.
3. WebSocket handshakes are accepted only from `chrome-extension://` origins.
4. Current and dedicated sessions use separate extensions, relay ports, and MCP namespaces.
5. The dedicated launcher uses a separate Chromium profile and disables sync.

Security boundary:

- All deep-debug tools remain enabled by design, including cookie and API-session export.
- `browser_qc_current` uses the user's active Chrome profile when current login state or extensions are required.
- `browser_qc_dedicated` uses an isolated profile for repeatable or risky test flows.
- The agent must select the session requested by the user and confirm it with `qc_session_info`.

Launch the isolated browser profile:

```powershell
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.codex\mcp\browser-mcp-x-dedicated\launch-dedicated-chrome.ps1"
```

Install the current-session extension once:

```powershell
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.codex\mcp\browser-mcp-x\open-current-session-install.ps1"
```

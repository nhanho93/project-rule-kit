# Browser MCP X QC Portable

Portable Windows bundle for browser E2E testing, visual UI/UX review, network inspection, and authenticated API debugging from MCP-compatible agents such as Codex and Antigravity.

## What is included

- `browser_qc_current`: controls the user's existing Chrome profile when its tabs, login state, or extensions are required.
- `browser_qc_dedicated`: controls an isolated Chromium profile for repeatable or risky test flows.
- `qc_e2e_checkpoint`: collects page metadata, ARIA state, console errors, network diagnostics, and a screenshot.
- `qc_visual_matrix`: captures mobile, tablet, and desktop screenshots.
- `qc_session_info`: confirms which browser session and ports are active.
- Full debug capability remains enabled: cookies, auth headers, API-session export, cURL generation, request payloads, JavaScript evaluation, and file upload.

The relay requires only Python 3. The Chrome extension has no npm build step.

## Install

Extract the ZIP, open PowerShell in the extracted folder, then run:

```powershell
powershell -ExecutionPolicy Bypass -File .\Install.ps1 -Agent All
```

Supported targets:

```powershell
.\Install.ps1 -Agent Codex
.\Install.ps1 -Agent Antigravity
.\Install.ps1 -Agent FilesOnly
```

Default install directory:

```text
%USERPROFILE%\.browser-mcp-x-qc
```

The installer backs up existing agent configuration before updating it and preserves unrelated MCP servers.

Antigravity CLI registration is written to:

```text
%USERPROFILE%\.gemini\config\mcp_config.json
```

The installer adds `browser_qc_current` and `browser_qc_dedicated` under
`mcpServers`; it does not replace existing servers.

Restart Codex or Antigravity after installation.

## Choose a browser session

### Dedicated session

Use this by default for E2E, visual regression, destructive test flows, or isolated test accounts.

```powershell
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.browser-mcp-x-qc\Start-Dedicated-QC.ps1"
```

The launcher prefers the newest locally installed Playwright Chromium and falls back to Google Chrome. It uses this isolated profile:

```text
%LOCALAPPDATA%\BrowserMCPX\ChromeProfile
```

### Current Chrome session

Run the setup helper once:

```powershell
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.browser-mcp-x-qc\Open-Current-Extension-Setup.ps1"
```

Enable **Developer mode**, choose **Load unpacked**, and paste the path already copied to the clipboard. Use `browser_qc_current` only when the task explicitly needs the current Chrome session.

## Recommended agent flow

1. Prefer the agent's native Chrome/browser connector when it is available and sufficient.
2. Use Browser MCP X QC as the fallback for deeper E2E, visual, network, API, or authenticated-session debugging.
3. Select `browser_qc_current` only when the user requests the current browser session.
4. Otherwise select `browser_qc_dedicated`.
5. Call `qc_session_info` before acting. Never silently switch sessions.
6. Run the user flow and capture `qc_e2e_checkpoint` at important transitions.
7. Run `qc_visual_matrix` before completing visual QA.

Default viewport matrix:

- Mobile: `390 x 844`
- Tablet: `1024 x 900`
- Desktop: `1440 x 1000`

## Security model

- HTTP and WebSocket listeners bind only to `127.0.0.1`.
- HTTP requests carrying a browser `Origin` header are rejected.
- WebSocket connections are accepted only from `chrome-extension://` origins.
- Current and dedicated sessions use different ports and extension builds.
- No cookies, tokens, browser profiles, test results, or credentials are included in this ZIP.

The extension is intentionally powerful. When current-session mode is active, its debug tools can access authenticated state in that Chrome profile. Agents should use those tools only within the user's requested scope.

## Verify

```powershell
powershell -ExecutionPolicy Bypass -File .\Self-Test.ps1
```

The test validates both MCP handshakes, session identity, and availability of QC and deep-debug tools without reading browser data.

## Uninstall

Remove MCP configuration only:

```powershell
.\Uninstall.ps1 -Agent All
```

Remove configuration and installed bundle files:

```powershell
.\Uninstall.ps1 -Agent All -RemoveFiles
```

Unpacked extensions must be removed manually from the browser's extension page.

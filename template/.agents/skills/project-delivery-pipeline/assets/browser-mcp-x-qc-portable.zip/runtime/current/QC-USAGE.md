# Browser MCP X - QC Usage

## Session routing

- Use `browser_qc_current` only when the request explicitly needs the user's current Chrome tabs, login state, or installed extensions.
- Use `browser_qc_dedicated` for isolated E2E, destructive flows, repeatable test data, or when no current-session dependency exists.
- Do not silently switch between sessions. Confirm the active instance with `qc_session_info` before executing a test flow.

## QC workflow

1. Confirm the selected session with `qc_session_info`.
2. Run the user flow with browser interaction tools.
3. Capture `qc_e2e_checkpoint` after important transitions.
4. Run `qc_visual_matrix` for mobile, tablet, and desktop evidence.
5. Review screenshots, ARIA state, console errors, failed requests, clipping, overflow, overlap, loading states, and responsive behavior.

Default visual matrix:

- Mobile: `390 x 844`
- Tablet: `1024 x 900`
- Desktop: `1440 x 1000`

## Debug capability

All extension tools remain available, including network headers, cookies, API-session export, cURL generation, JavaScript evaluation, and file upload. These are intentional QC/debug capabilities.

The current-session extension can access authenticated browser state in that Chrome profile. Use deep-debug tools only for the scope requested by the user. Prefer the dedicated profile for risky tests or when personal session state is unnecessary.

## Launchers

Current Chrome extension install helper:

```powershell
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.codex\mcp\browser-mcp-x\open-current-session-install.ps1"
```

Dedicated Chrome profile:

```powershell
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.codex\mcp\browser-mcp-x-dedicated\launch-dedicated-chrome.ps1"
```

The dedicated launcher prefers the newest local Playwright Chromium because current branded Chrome builds may ignore command-line unpacked-extension loading. It falls back to Google Chrome when Playwright Chromium is unavailable.

After changing `config.toml`, restart Codex once so both MCP namespaces are discovered.
